import React from 'react'
import { Link, useLoaderData } from 'react-router-dom';

export const MainNavigation = () => {

    const data = useLoaderData();
    const items = data.items;


  return (
    <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid">
            <div className="collapse navbar-collapse" id="navbarNav">
                <ul className="navbar-nav flex-column d-flex">
                    <li>
                        <Link className="nav-link mx-3" to="/">Home</Link>
                    </li>
                    <li>
                        <Link className="nav-link mx-3" to="/checkout">Checkout</Link>
                    </li>

                    { items.map(item => {
                        return (
                            <li key={Object.keys(item)[0]} className="nav-item">
                                <Link className="nav-link" to={`products/${Object.keys(item)[0]}`}> {Object.keys(item)[0]} </Link>
                            </li>
                        )
                    })
                    }
                </ul>
            </div>
        </div>
    </nav>
  )
}
