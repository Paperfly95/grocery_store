import React from 'react'
import { json, useLoaderData } from 'react-router';

export const Product = () => {

    const data = useLoaderData();

    const items = data.items;

    return (
        <>
            
        </>
    )
}

export async function loader() {
    const response = await fetch("http://localhost:8080/");

    if(!response.ok) {
        return json({message: 'Could not fetch items.'}, { status: 500});
    } else {
        return response;
    }
}