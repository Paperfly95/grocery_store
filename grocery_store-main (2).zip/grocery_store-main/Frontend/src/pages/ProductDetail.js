import React from 'react'

export const ProductDetail = () => {
  return (
    <div>ProductDetail</div>
  )
}
