import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Root } from './pages/Root';
import './App.css';
import Card from './components/card/card.js';
import { useState, useEffect } from 'react';
import Row from './components/row/row';
import Shoppingcart from './components/shoppingCart/shoppingCart';
import { Product ,loader as productLoader } from './pages/Product';
import { Home } from './pages/Home';
import { ProductDetail } from './pages/ProductDetail';



function App() {

  const route = createBrowserRouter([
    {
      path: "/",
      element: <Root />,
      loader: productLoader,
      children: [
        {
          index: true,
          element: <Home />
        },
        {
          path: "/products",
          element: <Product />,
          loader: productLoader,
        },
        {
          path: "/products/:id",
          element: <ProductDetail />
        }
      ]
    }
  ])

  return (
    <div>
      <RouterProvider router={route}></RouterProvider>
    </div>
  )
}

export default App;
