import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Root } from './pages/Root';
import './App.css';
import Card from './components/card/card.js';
import { useState, useEffect } from 'react';
import Row from './components/row/row';
import Shoppingcart from './components/shoppingCart/shoppingCart';
import { Product ,loader as productLoader } from './pages/Product';
import { Home } from './pages/Home';
import { ProductDetail, loader as productDetailsLoader } from './pages/ProductDetail';
import Uebertragen from './pages/Uebertragen';



function App() {

  const route = createBrowserRouter([
    {
      path: "/",
      element: <Root />,
      loader: productLoader,
      children: [
        {
          index: true,
          element: <Home />
        },
        {
          path: "/checkout",
          element: <Uebertragen />
        },
        {
          path: "/products",
          element: <Product />,
          loader: productLoader,
          children: [
            {
              path: ":id",
              id: "product-loader",
              loader: productDetailsLoader,
              children: [
                {
                  index: true, element: <ProductDetail />
                }
              ]
            },
          ]
        },
      ]
    }
  ])

  return (
    <div className="d-flex position-relative">
      <RouterProvider router={route}></RouterProvider>
    </div>
  )
}

export default App;
