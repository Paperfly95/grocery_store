import React from 'react'
import { MainNavigation } from '../components/MainNavigation'
import { Outlet } from 'react-router'

export const Root = () => {
  return (
    <>
        <MainNavigation />
        <main><Outlet /></main>
    </>
  )
}
