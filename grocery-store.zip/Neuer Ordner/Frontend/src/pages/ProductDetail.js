import React from 'react'
import ProductsList from '../components/ProductsList'
import { useRouteLoaderData } from "react-router-dom"

export const ProductDetail = () => {
  const { item } = useRouteLoaderData("product-loader")

  return (
    <>
        <ProductsList subProducts={Object.values(item)[0]}/>
    </>

  )
}

export async function loader({ request, params}) {
    const id = params.id;

    const response = await fetch("http://localhost:8080/items/" + id);
    console.log(response);
    return response;
}